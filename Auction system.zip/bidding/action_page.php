<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        .container {
            margin-top: 100px;
        }

        h1 {
            color: #4CAF50;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank You!</h1>
        <p>Please wait while we process your payment...</p>
        <h5> Please make sure you have send us your payment screenshot or reference number on following details:</h5>
        <h5>Email:ravigajurel123@gmail.com</h5> 
    <h5>phone/message/whatsapp/viber:9864684716</h5> 
<br>
    <h4> for further queries:<h4>
        <h3>CALL US AT:9864684716 </h3>
    
    </div>
</body>
</html>
