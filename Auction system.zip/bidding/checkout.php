<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            font-family: Arial;
            font-size: 17px;
            padding: 8px;
        }

        * {
            box-sizing: border-box;
        }

        .row {
            display: -ms-flexbox; /* IE10 */
            display: flex;
            -ms-flex-wrap: wrap; /* IE10 */
            flex-wrap: wrap;
            margin: 0 -16px;
        }

        .col-25 {
            -ms-flex: 25%; /* IE10 */
            flex: 25%;
        }

        .col-50 {
            -ms-flex: 50%; /* IE10 */
            flex: 50%;
        }

        .col-75 {
            -ms-flex: 75%; /* IE10 */
            flex: 75%;
        }

        .col-25,
        .col-50,
        .col-75 {
            padding: 0 16px;
        }

        .container {
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 20px;
        }

        input[type=text] {
            width: 100%;
            margin-bottom: 20px;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        label {
            margin-bottom: 10px;
            display: block;
        }

        .btn {
            padding: 12px;
            margin-top: 20px;
            border: none;
            width: 100%;
            border-radius: 3px;
            cursor: pointer;
            font-size: 17px;
            background-color: #4CAF50;
            color: white;
        }

        .btn:hover {
            background-color: #45a049;
        }

        a {
            color: #2196F3;
        }

        hr {
            border: 0px solid;
        }

        span.price {
            float: right;
            color: grey;
        }

        @media (max-width: 800px) {
            .row {
                flex-direction: column-reverse;
            }
            .col-25 {
                margin-bottom: 20px;
            }
        }

        #div1{
            background: #EFE17D;
            background: -webkit-linear-gradient(bottom, #EFE17D, #7D4275);
            background: -moz-linear-gradient(bottom, #EFE17D, #7D4275);
            background: linear-gradient(to top, #EFE17D, #7D4275);
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 20px;
        }

        #div1 p {
            text-align: justify;
        }

        h4 {
            font-size: 30px;
            font-family: Rockwell;
            color: transparent;
            text-align: center;
            animation: effect 2s linear infinite;
            margin-bottom: 20px;
        }

        @keyframes effect {
            0% {
                background: linear-gradient(
                        #E41B17, #FDD017);
                -webkit-background-clip: text;
            }

            100% {
                background: linear-gradient(
                        #FF6700, #E2F516);
                -webkit-background-clip: text;
            }
        }
    </style>
</head>
<body id="page-top">

<h4 style="font-family: Rockwell" align="center">Pay Your Bid Amount and Get Your Product..</h4>
<div class="row">
    <div class="col-25">
        <div class="container">
            <h4>Wishlist <span class="price" style="color: #8B0000"><i class="fa fa-shopping-cart"></i> <b>1</b></span></h4>
            <!-- Display the product details fetched from the URL parameters -->
            <p>Product Name: <?php echo isset($_GET['product_name']) ? htmlspecialchars($_GET['product_name']) : ''; ?></p>
            <p>Product Price: <?php echo isset($_GET['product_price']) ? htmlspecialchars($_GET['product_price']) : ''; ?></p>
            <!-- End of displaying product details -->
            <hr>
            <!-- Add the rest of your checkout details here -->
        </div>
    </div>
    <div class="col-75">
        <div class="container">
            <form action="action_page.php">
                <div id="div1" class="row">
                    <div class="col-50">
                        <h1> Pay Via esewa or khalti application and send a screenshot to us:</h1>
                          <h2>  Esewa/ khalti id:9864684716</h2>
                          <h1> you can scan the following qr as well:</h1>

                          <img src="https://cdn.ttgtmedia.com/rms/misc/qr_code_barcode.jpg" alt="Product Image" style="max-width: 100%; height: auto;">
                <h1>कृपया पैसा तिरिसकेपछी हामिलाई जानकारी गराउनुहोला</h1>
                <h3>Please mail or message us the screenshots of your payment or reference code to following:</h3>
                <h5>Email:ravigajurel123@gmail.com</h5> 
    <h5>phone/message/whatsapp/viber:9864684716</h5> 
        
    
                </div>
                
                <input type="submit" value="Continue to checkout" class="btn">
            </form>
        </div>
    </div>
</div>

</body>
</html>
