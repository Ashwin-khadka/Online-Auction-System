<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Auction</title>
    <?php include('admin\db_connect.php'); ?>
    <style>
        /* Your styles go here */
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="row mb-4 mt-4">
            <div class="col-md-12">
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <br>
                <div class="card">
                    <div class="card-header" align="center">
                        <h3><b>Order BidList</b></h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-condensed table-bordered table-dark">
                            <thead>
                                <tr>
                                    <th class="text-center">S.No.</th>
                                    <th class="">Product Name <i class="fa fa-list-alt"></i></th>
                                    <th class="">UserName <i class="fas fa-user"></i></th>
                                    <th class="">Amount <i class="fas fa-dollar-sign"></i></th>
                                    <th class="">Shipping <i class="fa fa-shopping-cart"></i></th>
                                    <th class="text-center">Apply/Cancel Your Order <i class="fab fa-cc-amazon-pay"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                $user_id = isset($_SESSION['login_id']) ? $_SESSION['login_id'] : 0;
                                $qry = $conn->query("SELECT b.*, u.name as uname, p.name, p.bid_end_datetime bdt FROM bids b INNER JOIN users u ON u.id = b.user_id INNER JOIN products p ON p.id = b.product_id WHERE b.user_id = $user_id");
                                while ($row = $qry->fetch_assoc()):
                                    $uid = $user_id;
                                ?>
                                <tr>
                                    <td class="text-center"><?php echo $i++ ?></td>
                                    <td class="">
                                        <p> <b><?php echo ucwords($row['name']) ?></b></p>
                                    </td>
                                    <td class="">
                                        <p> <b><?php echo ucwords($row['uname']) ?></b></p>
                                    </td>
                                    <td class="text-right">
                                        <p> <b><?php echo number_format($row['bid_amount'], 2) ?></b></p>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($row['status'] == 1): ?>
                                            <?php if (strtotime(date('Y-m-d H:i')) < strtotime($row['bdt'])): ?>
                                                <span class="badge badge-secondary">Bidding Stage</span>
                                            <?php else: ?>
                                                <?php if ($uid == $row['user_id']): ?>
                                                    <span class="badge badge-success">Shipping Your Product</span>
                                                <?php else: ?>
                                                    <span class="badge badge-secondary">Loose in Bidding</span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php elseif ($row['status'] == 2): ?>
                                            <span class="badge badge-primary">Confirmed</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Canceled</span>
                                        <?php endif; ?>
                                    </td>
                                    <td align="center">
                                        <a href="checkout.php?product_name=<?php echo urlencode($row['name']); ?>&product_price=<?php echo urlencode($row['bid_amount']); ?>">
                                            <button class="btn btn-primary btn-sm view_user" type="button"><i class="fa fa-sync"></i>Apply</button>
                                        </a>
                                        <button class="btn btn-danger btn-sm view_user" type="button" data-id="<?php echo $row['user_id']; ?>"><i class="fa fa-times"></i>Cancel</button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<p id="btn" align="right">
    <a href="index.php?page=checkout"> <button class="btn btn-success btn-sm view_user" type="button" data-id="<?php echo $row['user_id']; ?>">Online Payment <i class="fas fa-dollar-sign"></i></button></a>
    &nbsp;&nbsp;<a href="index.php?page=checkout"> <button class="btn btn-danger btn-sm view_user" type="button" data-id="<?php echo $row['user_id']; ?>">Cash On Delivery <i class="fas fa-dollar-sign"></i></button></a>
</p>
</body>
<script>
    // Your scripts go here
</script>
</html>
