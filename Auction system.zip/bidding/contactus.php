<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f9f9f9;
}

.container {
    width: 80%;
    margin: auto;
    padding: 20px;
}

.contact-info {
    background-color: #fff;
    padding: 40px;
    border-radius: 10px;
    margin-bottom: 40px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

.contact-info h2 {
    margin-top: 0;
    color: #333;
    text-align: center;
}

.contact-info p {
    color: #555;
    text-align: center;
}

.contact-info ul {
    list-style: none;
    padding: 0;
    margin-top: 30px;
}

.contact-info ul li {
    margin-bottom: 20px;
    text-align: center;
}

.social-icons {
    margin-top: 30px;
    text-align: center;
}

.social-icons a {
    text-decoration: none;
    color: #333;
    margin-right: 20px;
    font-size: 24px;
}

.social-icons a:hover {
    color: #007bff;
}

.form-container {
    background-color: #fff;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
}

form input[type=text],
form input[type=email],
form textarea {
    width: 100%;
    padding: 12px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

form input[type=submit] {
    background-color: #007bff;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    width: 100%;
    font-size: 16px;
}

form input[type=submit]:hover {
    background-color: #0056b3;
}

@media screen and (max-width: 600px) {
    .container {
        width: 100%;
    }
}
</style>
</head>
<body>

<div class="container">
    <div class="contact-info">
        <h2>Contact Us</h2>
        <h4>email:ravigajurel123@gmail.com</h4>
        <h4>phone:9864684716</h4>
        <h4>whatsapp/viber:9864684716</h4>
        <h4>Location:Kalanki-14,ktm</h4>
        <br>
        <h2>Feel free to get in touch with us. We are available on all major social media platforms.</h2>
       
        <div class="social-icons">
            <a href="https://www.facebook.com/janamaitri"><i class="fab fa-facebook"></i></a>
            <a href="https://www.facebook.com/janamaitri"><i class="fab fa-twitter"></i></a>
            <a href="https://www.facebook.com/janamaitri"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/janamaitri"><i class="fab fa-linkedin"></i></a>
        </div>
    </div>
    
    <div class="form-container">
        <h2>Any queries?message us</h2>
        <form action="" method="post">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Your name.." required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Your email.." >

            <label for="message">Message</label>
            <textarea id="message" name="message" placeholder="Write something.." style="height:200px" required></textarea>

            <input type="submit" value="Submit">
        </form>
    </div>
</div>

</body>
</html>
